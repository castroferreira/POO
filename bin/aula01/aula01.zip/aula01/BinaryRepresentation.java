package aula01;

public class BinaryRepresentation {

	public static void main(String[] args) {
		
		// see the binary representation of floating point numbers
		double n = 10.0;
		System.out.println(Long.toBinaryString(Double.doubleToRawLongBits(n)));
		
		// see the binary representation of negative integer numbers
		int x = -1;
		System.out.println(Integer.toBinaryString(x));
	}

}
