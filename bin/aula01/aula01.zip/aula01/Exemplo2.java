package aula01;

import java.util.Scanner;

public class Exemplo2 {

	public static void main(String[] args) {
		// declaration of integer variables before being used
		int a, b, r;
		
		// Scanner is used to read data from keyboard
		Scanner kb = new Scanner(System.in);
		System.out.print("a= ");
		a = kb.nextInt();
		System.out.print("b= ");
		b = kb.nextInt();
		
		// Arithmetic expression
		r = a + b;
		System.out.println("soma " + r);
		
		// integer division
		r = a / b;
		System.out.println("div " + r);
		
		double r2;
		r2 = (double)a / b; // cast can be used to change a variable type during the expression
		System.out.println("div " + r2);
		
		// Math class
		System.out.println("pot " + (Math.pow(a, b)));
		
	}

}
