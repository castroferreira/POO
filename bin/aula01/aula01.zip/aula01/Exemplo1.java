package aula01;

public class Exemplo1 {

	public static void main(String[] args) {
		
		System.out.println("bem vindos a POO");
		System.out.print(10);
	}

}
