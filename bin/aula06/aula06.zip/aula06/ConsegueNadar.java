package aula06;

public interface ConsegueNadar {

	public void nadar();
}
