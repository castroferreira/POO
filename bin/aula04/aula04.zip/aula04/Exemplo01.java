package aula04;
import aula03.Data;

public class Exemplo01 {

	public static void main(String[] args) {

		System.out.println("Objetos ao inicio: " + Data.getID());
		Data y = new Data();
		System.out.println(y);
		
		y = new Data();
		System.out.println(y);
		
		System.out.println("Dia de x: "+ y);
		for(int i = 0 ; i < 5 ; i++){
			Data x = new Data();
			System.out.println(x);
		}
		
		System.out.println(y + "ID de y = " + Data.getID());
		
		System.out.println("Objetos no fim: " + Data.getID());
		
	}

}
