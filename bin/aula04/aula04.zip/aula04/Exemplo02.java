package aula04;
import aula03.Data;

public class Exemplo02 {

	public static void main(String[] args) {

		System.out.println("Datas ao inicio: " + Data.getID());
		
		Data y = new Data();
		System.out.println(y);
		
		Data x = new Data(1, 20, 2000);
		System.out.println(x);
		
		System.out.println(x.equals(x) ? "iguais" : "diferentes");
		
		System.out.println(x.equals(y) ? "iguais" : "diferentes");
		
		System.out.println(x.bissexto() ? "bissexto" : "não bissexto");
		
		System.out.println("Datas no fim: " + Data.getID());
	}
}
