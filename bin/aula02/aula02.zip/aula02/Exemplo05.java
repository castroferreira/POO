package aula02;

public class Exemplo05 {

	public static void main(String[] args) {
		// for - using when we know how many times we want to repeat instructions
		
		for( int i = 0 ; i < 10 ; i++){
			System.out.println(i + " - POO");
		}
		
	}

}
