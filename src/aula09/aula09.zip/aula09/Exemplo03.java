package aula09;

import java.util.*;

public class Exemplo03 {

	public static void main(String[] args) {

		Map<String, Double> mapa = new HashMap<>();
		mapa.put("Rui", 32.4);
		mapa.put("Manuel", 3.2);
		mapa.put("Rita", 5.6);

		System.out.println("O Mapa contém " + mapa.size() + " elementos"); 
		System.out.println("O Rui está no Mapa? " + mapa.containsKey("Rui"));

		System.out.println("A Rita tem " +  mapa.get("Rita") + "€");
		mapa.put("Rita", mapa.get("Rita") + 3.6);
		System.out.println("A Rita tem " +  mapa.get("Rita") + "€");

		// Vistas do Map - uso da interface Map.Entry
		Set<Map.Entry<String, Double>> set = mapa.entrySet();
		for (Map.Entry<String, Double> ele: set)
			System.out.println("O " + ele.getKey() + " ganha " + ele.getValue() + "€");

		System.out.println(mapa);

	}

}
