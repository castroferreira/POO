package aula09;

import java.util.*;

public class Exemplo01 {

	public static void main(String[] args) {
		String[] str = {"Rui", "Manuel", "Rui", "Jose", "Pires", "Eduardo"};

		//List<String> lista = new ArrayList<>();
		List<String> lista = new ArrayList<>(); // Trocando a implementação da lista, o interface mantem-se
		
		/*// Uso de ciclo for "normal"
		for(int i = 0 ; i < str.length ; i++)
		  lista.add(str[i]);
		*/

		// foreach
		for(String s : str)
			lista.add(s);

		// toString está implementado nas Collections
		System.out.println(lista);

		// Uso de iteradores
		Iterator<String> it = lista.iterator();
		while(it.hasNext()) 
			System.out.println("iterador: " + it.next());

		// Ordenaçao pela ordem natural - método compareTo da classe
		lista.sort(null);
		System.out.println("ordenada " + lista);

		// Ordenação por uma classe tipo Comparator
		lista.sort(new LengthComparator());
		System.out.println("ordenada por length " + lista);
	}

}

class LengthComparator implements Comparator<String> {
	@Override
	public int compare(String a, String b) {
		return (a.length() > b.length() ? 1: -1);
	}
}

