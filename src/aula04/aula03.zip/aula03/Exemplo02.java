package aula03;

public class Exemplo02 {

	public static void main(String[] args) {
		// Example of using split and format
		
		String data = "1-1-17";
		String d[] = data.split("-");
		
		for(int i = 0 ; i < d.length ; i++){
			System.out.println(d[i]);
		}
		
		for(String s : d){
			System.out.println(s);
		}
		
		System.out.printf("%2s-%2s-%4s\n", d[0], d[1], d[2]);
		
		String novaData = String.format("%2s-%2s-%4s", d[0], d[1], d[2]);
		System.out.println("Nova data" + novaData);
	}

}
