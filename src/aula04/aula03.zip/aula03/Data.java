package aula03;

public class Data {
	private int d, m, a, myID;
	private static int id = 0;
	
	// setters and getters
	public static int getID(){
		return id;
	}
	
	public int getD() {
		return d;
	}

	public void setD(int d) {
		this.d = d;
	}

	public int getM() {
		return m;
	}

	public void setM(int m) {
		// assert(m >= 1 && m <= 12); 
		this.m = m;
	}

	public int getA() {
		return a;
	}

	public void setA(int a) {
		this.a = a;
	}

	// construtores
	public Data(){
		this.d = 1;
		this.m = 1;
		this.a = 2000;
		this.myID = id;
		id++;
	}
	
	public Data(int dia, int mes, int ano){
		// assert(mes >= 1 && mes <= 12); // assunto para aulas futuras
		
		this.d = dia;
		this.m = mes;
		this.a = ano;
		this.myID = id;
		id++;
	}
	
	// especiais
	public String toString(){
		return String.format("%2s-%2s-%4s (id = %d) (objCount = %d)", this.d , this.m, this.a, this.myID, id);
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + a;
		result = prime * result + d;
		result = prime * result + m;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		
		Data other = (Data) obj;
		if (a != other.a)
			return false;
		if (d != other.d)
			return false;
		if (m != other.m)
			return false;
		
		return true;
	}
	
	// outros - completar em casa
	
	public boolean  bissexto(){
		return this.a % 4 == 0;
	}
	
	public Data diaSeguinte(){
		return new Data();
	}
	
	public Data diaAnterior(){
		return new Data();
	}
	
}
