package aula03;

import java.util.Scanner;

public class Exemplo01 {

	public static void main(String[] args) {
		// Classes and objects - example using the String class

		String s = new String("ola");
		System.out.println(s);
		
		s = "aveiro"; // a new object is created
		System.out.println(s);

		// Accessing to the attributes of the object (number of carateres and each letter)
		for(int i = 0 ; i < s.length(); i++){
			System.out.println(s.charAt(i));
		}

		// Read text from the keyboard
		Scanner sc = new Scanner(System.in);
		System.out.print("Some text: ");
		String s2 = sc.nextLine();

		// Comparing objects - example with strings
		if(s.equals(s2)){
			System.out.println(s + " e igual a " + s2);
		}
		else{
			System.out.println(s + " e diferente de " + s2);
		}
	
	}

}
