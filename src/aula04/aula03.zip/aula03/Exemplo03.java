package aula03;

public class Exemplo03 {

	public static void main(String[] args) {
		// Declaring an object of class Data
		Data x = new Data();
		
		System.out.println(x); // by default its called toString method from the objects
		
		myF(); // calling local methods
	}

	// Declaring local methods
	public static void myF(){
		System.out.println("Tambem posso ter funcoes no programa");
	}
}
