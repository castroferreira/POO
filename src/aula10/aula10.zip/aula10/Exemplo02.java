package aula10;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Exemplo02 {

	public static void main(String[] args) {
		File f = new File("t2.txt");
		if(!f.exists())
			System.out.println("Fich nao existe!");
			
		Scanner scf = null;
		try {
			scf = new Scanner(f);
		} catch (FileNotFoundException e) {
			//e.printStackTrace();
			System.out.println("Fich nao existe (via exceção)!" + e);
			System.exit(0);
		}

		Map<String, String> mapa = new HashMap<>();
		while(scf.hasNextLine()){
			String s = scf.nextLine();
			System.out.println(s);
			String p[] = s.split(",");
			if(mapa.containsKey(p[0]))
				System.out.println("Chave existe!");
			
			mapa.put(p[0], p[1]);
		}
		
		System.out.println(mapa);
		scf.close();
	}

}
