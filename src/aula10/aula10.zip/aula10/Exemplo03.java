package aula10;

public class Exemplo03 {

	public static void main(String[] args) {

		System.out.println(divide(3, 0));

	}

	public static double divide(double a, double b){
		assert b!= 0;
		
		if(b != 0)
			return a / b;
		else
			return 0;
	}
}
