package aula10;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Exemplo01 {

	public static void main(String[] args) {
		File f = new File("tx.txt");
		if(!f.exists())
			System.out.println("Fich nao existe!");
			
		Scanner scf = null;
		try {
			scf = new Scanner(f);
		} catch (FileNotFoundException e) {
			//e.printStackTrace();
			System.out.println("Fich nao existe (via exceção)!" + e);
			System.exit(0);
		}
		finally{
			System.out.println("Sempre executado"); // comentar exit
		}
		
		File f2 = new File("out.txt");
		PrintWriter pw = null;
		try {
			pw = new PrintWriter(f2);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		while(scf.hasNextLine()){
			String s = scf.nextLine();
			System.out.println(s);
			pw.println(s);
		}
		
		pw.close();
		scf.close();
	}

}
